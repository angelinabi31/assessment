import 'dotenv/config';  
import express from "express";
import cors from "cors";
import taskRoutes from "./routes/taskRoutes.js";
import { corsOptions } from "./config/corsConfig.js";

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(cors(corsOptions));
app.use(express.json());


// Routes
app.use("/api/tasks", taskRoutes);

// Default route
app.get("/", (req, res) => {
  res.send("Task Manager API is running");
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
