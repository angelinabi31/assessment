import 'dotenv/config';
import { DynamoDBClient, CreateTableCommand } from "@aws-sdk/client-dynamodb";

// Initialize DynamoDB client
const client = new DynamoDBClient({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

// Define table parameters
const params = {
  TableName: "tasks",
  KeySchema: [
    { AttributeName: "id", KeyType: "HASH" }, // Partition key
  ],
  AttributeDefinitions: [
    { AttributeName: "id", AttributeType: "S" }, // S = String
  ],
  BillingMode: "PAY_PER_REQUEST", // On-demand
};

// Function to create table
const createTable = async () => {
  try {
    const data = await client.send(new CreateTableCommand(params));
    console.log("✅ Table created successfully:", data.TableDescription.TableName);
  } catch (err) {
    if (err.name === "ResourceInUseException") {
      console.log("ℹ️ Table already exists:", params.TableName);
    } else {
      console.error("❌ Error creating table:", err);
    }
  }
};

createTable();
