import express from "express";
import { getTasks, addTask, toggleTaskStatus, deleteTask } from "../controllers/taskController.js";

const router = express.Router();

router.get("/", getTasks);
router.post("/", addTask);
router.put("/:id/toggle", toggleTaskStatus);
router.delete("/:id", deleteTask);

export default router;
