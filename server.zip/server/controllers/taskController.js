import AWS from "aws-sdk";
import { v4 as uuidv4 } from "uuid";
import dynamoDb from "../dynamoClient.js";

const TABLE_NAME = "tasks";

// Get all tasks
export const getTasks = async (req, res) => {
  try {
    const data = await dynamoDb.scan({ TableName: TABLE_NAME }).promise();
    const tasks = data.Items.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json(tasks);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch tasks" });
  }
};

// Add a new task
export const addTask = async (req, res) => {
  const { title, description } = req.body;
  if (!title) return res.status(400).json({ message: "Title is required" });

  const newTask = {
    id: uuidv4(),
    title,
    description: description || "",
    status: "pending",
    createdAt: new Date().toISOString(),
  };

  try {
    await dynamoDb.put({ TableName: TABLE_NAME, Item: newTask }).promise();
    res.status(201).json(newTask);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to add task" });
  }
};

// Toggle task status
export const toggleTaskStatus = async (req, res) => {
  const { id } = req.params;

  try {
    // Get the current task
    const { Item } = await dynamoDb.get({ TableName: TABLE_NAME, Key: { id } }).promise();
    if (!Item) return res.status(404).json({ message: "Task not found" });

    const updatedStatus = Item.status === "pending" ? "completed" : "pending";

    // Update task
    const params = {
      TableName: TABLE_NAME,
      Key: { id },
      UpdateExpression: "set #status = :status",
      ExpressionAttributeNames: { "#status": "status" },
      ExpressionAttributeValues: { ":status": updatedStatus },
      ReturnValues: "ALL_NEW",
    };

    const updated = await dynamoDb.update(params).promise();
    res.json(updated.Attributes);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to toggle task status" });
  }
};




// Delete task
export const deleteTask = async (req, res) => {
  const { id } = req.params;

  try {
    await dynamoDb.delete({ TableName: TABLE_NAME, Key: { id } }).promise();
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to delete task" });
  }
};
