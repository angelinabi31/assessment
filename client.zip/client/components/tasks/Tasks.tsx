"use client";

import { useState } from "react";
import { motion } from "framer-motion";

interface Task {
  id: string;
  title: string;
  status: "pending" | "completed";
  description?: string;
}

export default function TaskManager() {
  // Dummy tasks (later from API)
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", title: "Design Homepage", status: "pending" },
    { id: "2", title: "Build Backend API", status: "completed" },
    { id: "3", title: "Deploy to Vercel", status: "pending" },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskDescription, setNewTaskDescription] = useState("");

  const addTask = () => {
    if (!newTaskTitle.trim()) return;

    setTasks([
      ...tasks,
      {
        id: String(Date.now()),
        title: newTaskTitle,
        description: newTaskDescription,
        status: "pending",
      },
    ]);

    setNewTaskTitle("");
    setNewTaskDescription("");
    setShowModal(false);
  };

  const toggleStatus = (id: string) => {
    setTasks(
      tasks.map((task) =>
        task.id === id
          ? {
              ...task,
              status: task.status === "pending" ? "completed" : "pending",
            }
          : task
      )
    );
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter((t) => t.id !== id));
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      {/* Header Section */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Task Manager</h1>

        <button
          onClick={()=>setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow"
        >
          + Add Task
        </button>
      </div>

      {/* Task Table */}
      <div className="overflow-x-auto bg-white shadow rounded-lg">
        <table className="min-w-full text-left">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-3">Title</th>
              <th className="p-3">Status</th>
              <th className="p-3 text-right">Actions</th>
            </tr>
          </thead>

          <tbody>
            {tasks.map((task) => (
              <tr key={task.id} className="border-b">
                <td className="p-3">{task.title}</td>
                <td className="p-3">
                  <span
                    className={`px-3 py-1 rounded-full text-sm ${
                      task.status === "completed"
                        ? "bg-green-200 text-green-700"
                        : "bg-yellow-200 text-yellow-700"
                    }`}
                  >
                    {task.status}
                  </span>
                </td>

                <td className="p-3 text-right">
                  <button
                    onClick={() => toggleStatus(task.id)}
                    className="mr-3 text-blue-600 hover:underline"
                  >
                    Toggle
                  </button>
                  <button
                    onClick={() => deleteTask(task.id)}
                    className="text-red-600 hover:underline"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex justify-center mt-5">
        <button className="px-3 py-1 border rounded-l-lg hover:bg-gray-200">
          Prev
        </button>
        <button className="px-3 py-1 border-t border-b hover:bg-gray-200">
          1
        </button>
        <button className="px-3 py-1 border rounded-r-lg hover:bg-gray-200">
          Next
        </button>
      </div>

      {/* Add Task Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white p-6 rounded-xl shadow-lg w-96"
          >
            <h2 className="text-xl font-semibold mb-4">Add New Task</h2>

            <input
              type="text"
              placeholder="Task title"
              className="w-full mb-3 p-2 border rounded"
              value={newTaskTitle}
              onChange={(e)=>setNewTaskTitle(e.target.value)}
            />

            <textarea
              placeholder="Description (optional)"
              className="w-full mb-3 p-2 border rounded"
              value={newTaskDescription}
              onChange={(e)=>setNewTaskDescription(e.target.value)}
            />

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border rounded"
              >
                Cancel
              </button>

              <button
                onClick={addTask}
                className="px-4 py-2 bg-blue-600 text-white rounded"
              >
                Add Task
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
