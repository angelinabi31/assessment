"use client";

import React from "react";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export default function Pagination({ currentPage, totalPages, onPageChange }: PaginationProps) {
  if (totalPages <= 1) return null;

  const getPages = () => {
    let pages: (number | "...")[] = [];
    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
      return pages;
    }
    if (currentPage <= 3) return [1, 2, 3, 4, "...", totalPages];
    if (currentPage >= totalPages - 2) return [1, "...", totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
    return [1, "...", currentPage - 1, currentPage, currentPage + 1, "...", totalPages];
  };

  const pages = getPages();

  return (
    <div className="flex justify-center mt-6">
      <div className="flex items-center border rounded-xl overflow-hidden">
        <button
          className={`px-4 py-2 border-r hover:bg-gray-100 ${currentPage === 1 ? "text-gray-400 cursor-not-allowed" : ""}`}
          disabled={currentPage === 1}
          onClick={() => currentPage > 1 && onPageChange(currentPage - 1)}
        >
          Prev
        </button>

        {pages.map((p, idx) =>
          p === "..." ? (
            <span key={idx} className="px-4 py-2 border-r text-gray-500">
              ...
            </span>
          ) : (
            <button
              key={p}
              onClick={() => onPageChange(Number(p))}
              className={`px-4 py-2 border-r hover:bg-gray-100 ${currentPage === p ? "bg-gray-200 font-semibold" : ""}`}
            >
              {p}
            </button>
          )
        )}

        <button
          className={`px-4 py-2 hover:bg-gray-100 ${currentPage === totalPages ? "text-gray-400 cursor-not-allowed" : ""}`}
          disabled={currentPage === totalPages}
          onClick={() => currentPage < totalPages && onPageChange(currentPage + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
}
