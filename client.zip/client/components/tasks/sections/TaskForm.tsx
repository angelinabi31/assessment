"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useTasks } from "@/context/TaskContext";

interface TaskFormProps {
  onClose: () => void;
  onAddTask: (title: string, description: string) => void;
}

export default function TaskForm({ onClose, onAddTask }: TaskFormProps) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!title.trim()) return;
    setLoading(true);
    try {
      await onAddTask(title, desc);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ scale: 0.85, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0.85, opacity: 0 }}
      className="fixed z-50 w-full max-w-md p-6 bg-white rounded-xl shadow-2xl top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
    >
      <h2 className="text-2xl font-semibold mb-5 text-gray-800">Add New Task</h2>

      <input
        type="text"
        placeholder="Task title"
        className="w-full mb-4 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      <textarea
        placeholder="Description (optional)"
        className="w-full mb-4 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
        value={desc}
        onChange={(e) => setDesc(e.target.value)}
      />

      <div className="flex justify-end gap-3">
        <button onClick={onClose} className="px-4 py-2 border rounded-lg hover:bg-gray-100 transition" disabled={loading}>
          Cancel
        </button>
        <button
          onClick={handleSubmit}
          className="px-5 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition disabled:opacity-50"
          disabled={loading}
        >
          {loading ? "Saving..." : "Add"}
        </button>
      </div>
    </motion.div>
  );
}
