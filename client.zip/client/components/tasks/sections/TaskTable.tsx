"use client";

import { useTasks, Task } from "@/context/TaskContext";
import { CheckCircleIcon, XCircleIcon, TrashIcon } from "@heroicons/react/24/outline";

interface TaskTableProps {
  currentTasks?: Task[]; // optional for pagination
}

export default function TaskTable({ currentTasks }: TaskTableProps) {
  const { tasks, toggleStatus, deleteTask, loading } = useTasks();

  const displayTasks = currentTasks || tasks;

  if (loading) return <p className="text-center py-8">Loading tasks...</p>;

  return (
    <div className="w-full overflow-x-auto rounded-xl border border-gray-300 bg-white shadow-sm">
      <table className="w-full min-w-[600px] text-left border-collapse">
        <thead>
          <tr className="bg-gray-100 text-gray-700 uppercase text-xs md:text-sm">
            <th className="px-4 md:px-6 py-3 border-b border-gray-300">Task</th>
            <th className="px-4 md:px-6 py-3 border-b border-gray-300">Status</th>
            <th className="px-4 md:px-6 py-3 border-b border-gray-300 text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          {displayTasks.map((task, idx) => (
            <tr
              key={task.id}
              className={`border-b border-gray-200 transition-all duration-200 ${
                idx % 2 === 0 ? "bg-white" : "bg-gray-50"
              } hover:bg-gray-200`}
            >
              <td className="px-4 md:px-6 py-4 font-medium">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={task.status === "completed"}
                    onChange={() => toggleStatus(task.id)}
                    className="w-5 h-5 cursor-pointer border border-gray-600 transition-all"
                  />
                  <span className={`text-sm md:text-base ${task.status === "completed" ? "line-through text-gray-500" : ""}`}>
                    {task.title}
                  </span>
                </div>
              </td>
              <td className="px-4 md:px-6 py-4">
                <span className={`text-xs font-semibold px-3 py-1 rounded ${
                  task.status === "completed" ? "bg-green-200 text-green-800" : "bg-yellow-200 text-yellow-800"
                }`}>
                  {task.status === "completed" ? "Completed" : "Pending"}
                </span>
              </td>
              <td className="px-4 md:px-6 py-4 text-right">
                <div className="flex justify-end gap-3 md:gap-4">
                  <button onClick={() => toggleStatus(task.id)} className="transition hover:scale-110">
                    {task.status === "pending" ? <CheckCircleIcon className="w-6 h-6 text-blue-600" /> : <XCircleIcon className="w-6 h-6 text-orange-600" />}
                  </button>
                  <button onClick={() => deleteTask(task.id)} className="transition hover:scale-110">
                    <TrashIcon className="w-6 h-6 text-red-600" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
          {displayTasks.length === 0 && (
            <tr>
              <td colSpan={3} className="py-8 text-center text-gray-500 text-sm md:text-base">
                No tasks found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
