"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import TaskTable from "./sections/TaskTable";
import Pagination from "./sections/Pagination";
import TaskForm from "./sections/TaskForm";
import { useTasks } from "@/context/TaskContext";

export default function TaskManager() {
  const { tasks, addTask } = useTasks();
  const [showModal, setShowModal] = useState(false);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const tasksPerPage = 5;
  const totalPages = Math.ceil(tasks.length / tasksPerPage);
  const currentTasks = tasks.slice(
    (currentPage - 1) * tasksPerPage,
    currentPage * tasksPerPage
  );

  // Add task at the top
  const handleAddTask = async (title: string, description: string) => {
    await addTask(title, description);
    setShowModal(false);
    setCurrentPage(1); // go to first page to see new task
  };

  return (
    <div className="max-w-6xl mx-auto p-6 md:p-8 min-h-screen bg-gray-50 relative">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 md:mb-12 gap-4">
        <h1 className="text-3xl md:text-4xl font-extrabold text-gray-800 tracking-tight">
          Task Manager
        </h1>

        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
        >
          + Add Task
        </button>
      </div>

      {/* Task Table */}
      <TaskTable currentTasks={currentTasks} />

      {/* Pagination */}
      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={(page) => setCurrentPage(page)}
      />

      {/* Modal Overlay & Form */}
      <AnimatePresence>
        {showModal && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.3 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black z-40 backdrop-blur-sm"
              onClick={() => setShowModal(false)}
            />

            {/* Modal */}
            <TaskForm
              onClose={() => setShowModal(false)}
              onAddTask={handleAddTask}
            />
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
