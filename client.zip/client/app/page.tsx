import TaskManager from "@/components/tasks/TaskManager";
import { TaskProvider } from "@/context/TaskContext";

export default function Home() {
  return (
    <TaskProvider>
    <TaskManager />
    </TaskProvider>

  );
}
