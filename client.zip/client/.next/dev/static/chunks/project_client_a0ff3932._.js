(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_49ea6fb9._.js",
  "static/chunks/fe088_next_dist_compiled_react-dom_b0892ad1._.js",
  "static/chunks/fe088_next_dist_compiled_react-server-dom-turbopack_98c0e0f8._.js",
  "static/chunks/fe088_next_dist_compiled_next-devtools_index_ccb99384.js",
  "static/chunks/fe088_next_dist_compiled_cfee63bc._.js",
  "static/chunks/fe088_next_dist_client_7ab8274b._.js",
  "static/chunks/fe088_next_dist_75db9c30._.js",
  "static/chunks/fe088_@swc_helpers_cjs_eb658c4d._.js"
],
    source: "entry"
});
