(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1adc6d89._.js",
  "static/chunks/components_tasks_5a1f38d0._.js"
],
    source: "dynamic"
});
