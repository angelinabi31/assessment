(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fe088_7f9691c3._.js",
  "static/chunks/project_client_b3c82720._.js"
],
    source: "dynamic"
});
