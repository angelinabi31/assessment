module.exports = [
"[project]/project/client/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=project_client__next-internal_server_app_page_actions_93ae935a.js.map