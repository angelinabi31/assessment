globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/fe088_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_49ea6fb9._.js",
    "static/chunks/fe088_next_dist_compiled_react-dom_b0892ad1._.js",
    "static/chunks/fe088_next_dist_compiled_react-server-dom-turbopack_98c0e0f8._.js",
    "static/chunks/fe088_next_dist_compiled_next-devtools_index_ccb99384.js",
    "static/chunks/fe088_next_dist_compiled_cfee63bc._.js",
    "static/chunks/fe088_next_dist_client_7ab8274b._.js",
    "static/chunks/fe088_next_dist_75db9c30._.js",
    "static/chunks/fe088_@swc_helpers_cjs_eb658c4d._.js",
    "static/chunks/project_client_a0ff3932._.js",
    "static/chunks/turbopack-project_client_42dfbf66._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];